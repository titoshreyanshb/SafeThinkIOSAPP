import UIKit
import CoreML
import FirebaseFirestore
import Firebase


struct FlaggedWord: Identifiable, Codable, Equatable {
    let id: UUID
    let text: String
    let timestamp: Date
    let generatedByUID: String
    var uploadedToFirestore: Bool

    init?(dictionary: [String: Any]) {
        guard
            let idString = dictionary["id"] as? String,
            let uuid = UUID(uuidString: idString),
            let text = dictionary["text"] as? String,
            let timestamp = dictionary["timestamp"] as? Date,
            let generatedByUID = dictionary["generatedByUID"] as? String
        else {
            return nil
        }
        self.id = uuid
        self.text = text
        self.timestamp = timestamp
        self.generatedByUID = generatedByUID
        self.uploadedToFirestore = dictionary["uploaded"] as? Bool ?? false
    }

    func toDictionary() -> [String: Any] {
        return [
            "id": id.uuidString,
            "text": text,
            "timestamp": timestamp,
            "generatedByUID": generatedByUID,
            "uploaded": uploadedToFirestore
        ]
    }
}

class KeyboardViewController: UIInputViewController {
    
    enum KeyboardMode {
        case letters
        case numbersSymbols
    }
    
    private var analysisTimer: Timer?
    let appGroupId = "group.com.safethink.app"
    
    let model: safethinkdetection = {
        do {
            let config = MLModelConfiguration()
            return try safethinkdetection(configuration: config)
        } catch {
            fatalError("Model failed to load: \(error)")
        }
    }()
    
    let keyboardStackView = UIStackView()
    var currentMode: KeyboardMode = .letters {
        didSet {
            if oldValue != currentMode {
                animateKeyboardModeSwitch(from: oldValue, to: currentMode)
            }
        }
    }
    var isShiftActive = false {
        didSet {
            updateShiftKeyState()
            updateLetterCase()
        }
    }
    var isCapsLockActive = false {
        didSet {
            updateShiftKeyState()
            updateLetterCase()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if FirebaseApp.app() == nil {
            FirebaseApp.configure()
            print("✅ Firebase configured in Keyboard Extension")
        }

        let sharedDefaults = UserDefaults(suiteName: "group.com.safethink.app")
        sharedDefaults?.set("🧠 hello from keyboard", forKey: "debugKey")
        print("✅ KEYBOARD WROTE")

        setupKeyboard()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        isShiftActive = false
        isCapsLockActive = false
        updateLetterCase()
        updateShiftKeyState()
    }
    
    private func setupKeyboard() {
        view.backgroundColor = UIColor(named: "KeyboardBackgroundColor") ?? UIColor(red: 0.84, green: 0.85, blue: 0.87, alpha: 1.0)
        
        keyboardStackView.axis = .vertical
        keyboardStackView.spacing = 8
        keyboardStackView.distribution = .fillEqually
        keyboardStackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(keyboardStackView)
        
        NSLayoutConstraint.activate([
            keyboardStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4),
            keyboardStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4),
            keyboardStackView.topAnchor.constraint(equalTo: view.topAnchor, constant: 4),
            keyboardStackView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -4)
        ])
        
        loadKeyboardForCurrentMode()
        
        isShiftActive = false
        isCapsLockActive = false
        updateLetterCase()
        updateShiftKeyState()
    }
    
    func animateKeyboardModeSwitch(from oldMode: KeyboardMode, to newMode: KeyboardMode) {
        let oldKeyboardSnapshot = keyboardStackView.snapshotView(afterScreenUpdates: false)
        
        self.keyboardStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        loadKeyboardContent(for: newMode)
        keyboardStackView.alpha = 0.0
        
        if let snapshot = oldKeyboardSnapshot {
            snapshot.translatesAutoresizingMaskIntoConstraints = false
            view.insertSubview(snapshot, aboveSubview: keyboardStackView)
            
            NSLayoutConstraint.activate([
                snapshot.leadingAnchor.constraint(equalTo: keyboardStackView.leadingAnchor),
                snapshot.trailingAnchor.constraint(equalTo: keyboardStackView.trailingAnchor),
                snapshot.topAnchor.constraint(equalTo: keyboardStackView.topAnchor),
                snapshot.bottomAnchor.constraint(equalTo: keyboardStackView.bottomAnchor)
            ])
        }
        
        UIView.animate(withDuration: 0.2, animations: {
            oldKeyboardSnapshot?.alpha = 0.0
            self.keyboardStackView.alpha = 1.0
        }) { _ in
            oldKeyboardSnapshot?.removeFromSuperview()
        }
    }
    
    func loadKeyboardContent(for mode: KeyboardMode) {
        switch mode {
        case .letters:
            self.loadLettersKeyboard()
        case .numbersSymbols:
            self.loadNumbersSymbolsKeyboard()
        }
        self.keyboardStackView.layoutIfNeeded()
    }
    
    func loadKeyboardForCurrentMode() {
        loadKeyboardContent(for: currentMode)
        keyboardStackView.alpha = 1.0
    }
    
    func loadLettersKeyboard() {
        let rowsData = [
            ["Q","W","E","R","T","Y","U","I","O","P"],
            ["A","S","D","F","G","H","J","K","L"],
            ["Shift","Z","X","C","V","B","N","M","Delete"]
        ]
        
        let shiftDeleteKeyWidthRatio: CGFloat = 0.135
        let utilityButtonRatio: CGFloat = 0.23
        
        for (rowIndex, rowKeys) in rowsData.enumerated() {
            let rowStack = makeRowStack()
            keyboardStackView.addArrangedSubview(rowStack)
            
            switch rowIndex {
            case 0, 1:
                rowStack.distribution = .fillEqually
                for keyTitle in rowKeys {
                    let button = makeKeyButton(title: keyTitle)
                    rowStack.addArrangedSubview(button)
                }
            case 2:
                rowStack.distribution = .fill
                rowStack.spacing = 6
                
                let shiftButton = makeKeyButton(title: "Shift")
                rowStack.addArrangedSubview(shiftButton)
                shiftButton.widthAnchor.constraint(equalTo: rowStack.widthAnchor, multiplier: shiftDeleteKeyWidthRatio).isActive = true
                
                let letterKeysInRow = rowKeys[1..<(rowKeys.count - 1)]
                let lettersStack = UIStackView()
                lettersStack.axis = .horizontal
                lettersStack.spacing = 6
                lettersStack.distribution = .fillEqually
                for letterTitle in letterKeysInRow {
                    let letterButton = makeKeyButton(title: letterTitle)
                    lettersStack.addArrangedSubview(letterButton)
                }
                rowStack.addArrangedSubview(lettersStack)
                
                let deleteButton = makeKeyButton(title: "Delete")
                rowStack.addArrangedSubview(deleteButton)
                deleteButton.widthAnchor.constraint(equalTo: rowStack.widthAnchor, multiplier: shiftDeleteKeyWidthRatio).isActive = true
                
            default:
                break
            }
        }
        
        let bottomRowStack = makeRowStack()
        keyboardStackView.addArrangedSubview(bottomRowStack)
        bottomRowStack.distribution = .fill
        bottomRowStack.spacing = 6
        
        let key123 = makeKeyButton(title: "123")
        let spaceButton = makeKeyButton(title: "Space")
        let returnButton = makeKeyButton(title: "return")
        
        bottomRowStack.addArrangedSubview(key123)
        bottomRowStack.addArrangedSubview(spaceButton)
        bottomRowStack.addArrangedSubview(returnButton)
        
        key123.widthAnchor.constraint(equalTo: bottomRowStack.widthAnchor, multiplier: utilityButtonRatio).isActive = true
        returnButton.widthAnchor.constraint(equalTo: bottomRowStack.widthAnchor, multiplier: utilityButtonRatio).isActive = true
        
        spaceButton.setContentHuggingPriority(.defaultLow, for: .horizontal)
        spaceButton.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        
        updateLetterCase()
        updateShiftKeyState()
    }
    
    func loadNumbersSymbolsKeyboard() {
        let rowsData = [
            ["1","2","3","4","5","6","7","8","9","0"],
            ["-","/",";",":","(",")","$","&","@","\""],
            ["#+=",".",",","?","!","'","Delete"]
        ]
        
        let symbolUtilityKeyWidthRatio: CGFloat = 0.18
        let deleteKeyWidthRatio: CGFloat = 0.135
        let utilityButtonRatio: CGFloat = 0.23
        
        for (rowIndex, rowKeys) in rowsData.enumerated() {
            let rowStack = makeRowStack()
            keyboardStackView.addArrangedSubview(rowStack)
            
            switch rowIndex {
            case 0, 1:
                rowStack.distribution = .fillEqually
                for keyTitle in rowKeys {
                    let button = makeKeyButton(title: keyTitle)
                    rowStack.addArrangedSubview(button)
                }
            case 2:
                rowStack.distribution = .fill
                rowStack.spacing = 6
                
                let hashPlusEqualButton = makeKeyButton(title: "#+=")
                rowStack.addArrangedSubview(hashPlusEqualButton)
                hashPlusEqualButton.widthAnchor.constraint(equalTo: rowStack.widthAnchor, multiplier: symbolUtilityKeyWidthRatio).isActive = true
                
                let symbolKeysInRow = rowKeys[1..<(rowKeys.count - 1)]
                let symbolsStack = UIStackView()
                symbolsStack.axis = .horizontal
                symbolsStack.spacing = 6
                symbolsStack.distribution = .fillEqually
                for symbolTitle in symbolKeysInRow {
                    let symbolButton = makeKeyButton(title: symbolTitle)
                    symbolsStack.addArrangedSubview(symbolButton)
                }
                rowStack.addArrangedSubview(symbolsStack)
                
                let deleteButton = makeKeyButton(title: "Delete")
                rowStack.addArrangedSubview(deleteButton)
                deleteButton.widthAnchor.constraint(equalTo: rowStack.widthAnchor, multiplier: deleteKeyWidthRatio).isActive = true
                
            default:
                break
            }
        }
        
        let bottomRowStack = makeRowStack()
        keyboardStackView.addArrangedSubview(bottomRowStack)
        bottomRowStack.distribution = .fill
        bottomRowStack.spacing = 6
        
        let keyABC = makeKeyButton(title: "ABC")
        let spaceButton = makeKeyButton(title: "Space")
        let returnButton = makeKeyButton(title: "return")
        
        bottomRowStack.addArrangedSubview(keyABC)
        bottomRowStack.addArrangedSubview(spaceButton)
        bottomRowStack.addArrangedSubview(returnButton)
        
        keyABC.widthAnchor.constraint(equalTo: bottomRowStack.widthAnchor, multiplier: utilityButtonRatio).isActive = true
        returnButton.widthAnchor.constraint(equalTo: bottomRowStack.widthAnchor, multiplier: utilityButtonRatio).isActive = true
        
        spaceButton.setContentHuggingPriority(.defaultLow, for: .horizontal)
        spaceButton.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
    }
    
    func makeRowStack() -> UIStackView {
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.spacing = 6
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.heightAnchor.constraint(equalToConstant: 48).isActive = true
        return stack
    }
    
    func makeKeyButton(title: String) -> UIButton {
        let button = UIButton(type: .system)
        button.setTitle(title, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 21, weight: .light)
        button.layer.cornerRadius = 7
        button.adjustsImageWhenHighlighted = false
        
        button.addTarget(self, action: #selector(keyTapped(_:)), for: .touchUpInside)
        button.addGestureRecognizer(UILongPressGestureRecognizer(target: self, action: #selector(keyLongPressed(_:))))
        
        button.addAction(UIAction { _ in
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        }, for: .touchDown)
        
        button.setTitleColor(UIColor(named: "StandardKeyTextColor") ?? .black, for: .normal)
        
        switch title {
        case "Space":
            button.backgroundColor = UIColor(named: "StandardKeyBackgroundColor") ?? UIColor(white: 0.995, alpha: 1.0)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: .regular)
        case "return":
            button.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            button.setTitleColor(UIColor(named: "StandardKeyTextColor") ?? .black, for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: .regular)
        case "Delete":
            button.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            if let image = UIImage(systemName: "delete.left.fill") {
                button.setImage(image, for: .normal)
                button.imageView?.tintColor = .black
                button.setTitle("", for: .normal)
           
                button.contentVerticalAlignment = .center
                button.contentHorizontalAlignment = .center
                button.imageEdgeInsets = UIEdgeInsets(top: 14, left: 14, bottom: 14, right: 14)
            }
        case "Shift":
            button.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            button.imageView?.tintColor = .black
  
            button.contentVerticalAlignment = .center
            button.contentHorizontalAlignment = .center
            button.imageEdgeInsets = UIEdgeInsets(top: 14, left: 14, bottom: 14, right: 14)
            
           
            button.setImage(UIImage(systemName: "arrow.up"), for: .normal)
            button.setTitle("", for: .normal)
            
        case "123", "ABC", "#+=":
            button.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 17, weight: .regular)
        default:
            
            button.backgroundColor = UIColor(named: "StandardKeyBackgroundColor") ?? UIColor(white: 0.995, alpha: 1.0)
        }
        
        return button
    }
    

    @objc func keyTapped(_ sender: UIButton) {
        let proxy = textDocumentProxy
        UIDevice.current.playInputClick()
        
        
 
        let key: String?
        if let title = sender.currentTitle, !title.isEmpty {
            key = title
        } else if sender.imageView?.image == UIImage(systemName: "delete.left.fill") {
            key = "Delete"
        } else if sender.imageView?.image == UIImage(systemName: "arrow.up") || sender.imageView?.image == UIImage(systemName: "arrow.up.fill") || sender.imageView?.image == UIImage(systemName: "capslock.fill") {
            key = "Shift"
        } else {
            key = nil
        }
        
      
        if key == "return" {
            sender.backgroundColor = UIColor(named: "ActionKeyPressedColor") ?? UIColor(red: 0.68, green: 0.69, blue: 0.72, alpha: 1.0)
        } else if key == "Shift" && (self.isShiftActive || self.isCapsLockActive) {
            sender.backgroundColor = UIColor(named: "ActionKeyPressedColor") ?? UIColor(red: 0.68, green: 0.69, blue: 0.72, alpha: 1.0)
        } else if key == "Space" {
            sender.backgroundColor = UIColor(named: "SpaceKeyPressedColor") ?? UIColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1.0)
        } else if key == "Delete" || key == "123" || key == "ABC" || key == "#+=" {
            sender.backgroundColor = UIColor(named: "ActionKeyPressedColor") ?? UIColor(red: 0.68, green: 0.69, blue: 0.72, alpha: 1.0)
        } else {
            sender.backgroundColor = UIColor(named: "StandardKeyPressedColor") ?? UIColor(red: 0.88, green: 0.88, blue: 0.88, alpha: 1.0)
        }
        
       
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            if key == "return" {
                sender.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            } else if key == "Space" {
                sender.backgroundColor = UIColor(named: "StandardKeyBackgroundColor") ?? UIColor(white: 0.995, alpha: 1.0)
            } else if key == "Delete" || key == "123" || key == "ABC" || key == "#+=" {
                sender.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            } else if key == "Shift" {
                self.updateShiftKeyState(for: sender)
            }
            else {
                sender.backgroundColor = UIColor(named: "StandardKeyBackgroundColor") ?? UIColor(white: 0.995, alpha: 1.0)
            }
        }
        
        guard let unwrappedKey = key else { return }
        
        switch unwrappedKey.lowercased() {
        case "shift":
            self.handleShiftKey()
        case "delete":
            proxy.deleteBackward()
            resetAnalysisTimer()
        case "space":
            proxy.insertText(" ")
            resetAnalysisTimer()
        case "return":
            proxy.insertText("\n")
            resetAnalysisTimer()
        case "123", "#+=":
            currentMode = .numbersSymbols
        case "abc":
            currentMode = .letters
        case "globe":
            advanceToNextInputMode()
        default:
            
            if currentMode == .letters {
                let text = applyShift(to: unwrappedKey)
                proxy.insertText(text)
                
                if isShiftActive && !isCapsLockActive {
                    isShiftActive = false
                }
            } else {
                proxy.insertText(unwrappedKey)
            }
            resetAnalysisTimer()
        }
    }
    
   
    func handleShiftKey() {
        if isShiftActive && !isCapsLockActive {
            isCapsLockActive = true
            isShiftActive = false
        } else if isCapsLockActive {
            isCapsLockActive = false
        } else {
            isShiftActive = true
        }
    }
    
   
    @objc func keyLongPressed(_ gesture: UILongPressGestureRecognizer) {
        guard gesture.state == .began, let button = gesture.view as? UIButton else { return }
        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        
        if button.currentTitle == "Shift" || button.imageView?.image == UIImage(systemName: "arrow.up") || button.imageView?.image == UIImage(systemName: "arrow.up.fill") || button.imageView?.image == UIImage(systemName: "capslock.fill") {
            isCapsLockActive.toggle()
            isShiftActive = false
        }
      
        else if button.currentTitle == "123" || button.currentTitle == "ABC" {
            advanceToNextInputMode()
        }
    }
    
    
    func applyShift(to key: String) -> String {
        
        return (isCapsLockActive || isShiftActive) ? key.uppercased() : key.lowercased()
    }
    
    override func textWillChange(_ textInput: UITextInput?) {}
    override func textDidChange(_ textInput: UITextInput?) {
        updateShiftKeyState()
        resetAnalysisTimer()
    }
    
   
    
   
    func updateLetterCase() {
        guard currentMode == .letters else { return }
        for view in keyboardStackView.arrangedSubviews {
            if let rowStack = view as? UIStackView {
                for subview in rowStack.arrangedSubviews {
                    if let button = subview as? UIButton {
                        
                        guard let title = button.currentTitle else { continue }
                        if title.count == 1 && title.range(of: "[A-Za-z]", options: .regularExpression) != nil {
                            let newTitle = (isCapsLockActive || isShiftActive) ? title.uppercased() : title.lowercased()
                            button.setTitle(newTitle, for: .normal)
                            
                        }
                    } else if let nestedStack = subview as? UIStackView {
                        
                        for case let nestedButton as UIButton in nestedStack.arrangedSubviews {
                            guard let title = nestedButton.currentTitle else { continue }
                            if title.count == 1 && title.range(of: "[A-Za-z]", options: .regularExpression) != nil {
                                let newTitle = (isCapsLockActive || isShiftActive) ? title.uppercased() : title.lowercased()
                                nestedButton.setTitle(newTitle, for: .normal)
                                
                            }
                        }
                    }
                }
            }
        }
    }
    
    
    func updateShiftKeyState(for button: UIButton? = nil) {
        var shiftButton: UIButton? = nil
        for view in keyboardStackView.arrangedSubviews {
            if let rowStack = view as? UIStackView {
                for subview in rowStack.arrangedSubviews {
                    if let btn = subview as? UIButton, (btn.currentTitle == "Shift" || (btn.imageView?.image != nil && (btn.imageView?.image == UIImage(systemName: "arrow.up") || btn.imageView?.image == UIImage(systemName: "arrow.up.fill") || btn.imageView?.image == UIImage(systemName: "capslock.fill")))) {
                        shiftButton = btn
                        break
                    }
                }
            }
            if shiftButton != nil { break }
        }
        
        guard let sButton = shiftButton else { return }
        
        
        if self.isCapsLockActive {
            sButton.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            sButton.tintColor = .black
            sButton.setImage(UIImage(systemName: "capslock.fill"), for: .normal)
            sButton.setTitle("", for: .normal)
        } else if self.isShiftActive {
            sButton.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            sButton.tintColor = .black
            sButton.setImage(UIImage(systemName: "arrow.up.fill"), for: .normal)
            sButton.setTitle("", for: .normal)
        } else {
            sButton.backgroundColor = UIColor(named: "ActionKeyBackgroundColor") ?? UIColor(red: 0.79, green: 0.80, blue: 0.83, alpha: 1.0)
            sButton.tintColor = .black
            sButton.setImage(UIImage(systemName: "arrow.up"), for: .normal)
            sButton.setTitle("", for: .normal)
        }
    }
    
    
    
    private func resetAnalysisTimer() {
        analysisTimer?.invalidate()
        analysisTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { [weak self] _ in
            self?.performTextAnalysis()
        }
    }
    
    private func performTextAnalysis() {
        guard let text = textDocumentProxy.documentContextBeforeInput else { return }
        print("KEYBOARD_DEBUG: Starting text analysis for input: \"\(text)\"")
        
        do {
            let prediction = try model.prediction(text: text)
            let isToxic = prediction.label == "suicide"
            
            if isToxic {
                print("KEYBOARD_DEBUG: Detected toxic text: \"\(text)\". Calling saveFlagmedText.")
                saveFlagmedText(text)
            } else {
                print("KEYBOARD_DEBUG: Text is not toxic: \"\(text)\". No flagging needed.")
            }
        } catch {
            print("KEYBOARD_DEBUG_ERROR: Error performing text analysis: \(error.localizedDescription)")
        }
    }
    
    func saveFlagmedText(_ text: String) {
        print("KEYBOARD_DEBUG: saveFlagmedText function called with text: \"\(text)\"")
        
        guard let defaults = UserDefaults(suiteName: appGroupId) else {
            print("KEYBOARD_DEBUG_ERROR: UserDefaults(suiteName: \(appGroupId)) is NIL. App Group may not be configured.")
            return
        }
        
        var logs = defaults.array(forKey: "FlaggedTexts") as? [[String: Any]] ?? []
        print("KEYBOARD_DEBUG: Loaded \(logs.count) existing raw dictionaries from UserDefaults.")
        
        let currentUserUID = defaults.string(forKey: "currentUserUID")
        print("KEYBOARD_DEBUG: currentUserUID from UserDefaults: \(currentUserUID ?? "NIL")")
        
        let generatedByUID = currentUserUID ?? "unauthenticated"
        if currentUserUID == nil {
            print("WARNING_KEYBOARD: currentUserUID is nil. Flagged text will be saved with 'unauthenticated'.")
        } else {
            print("DEBUG_KEYBOARD: Flagged text will be saved with generatedByUID: \(generatedByUID).")
        }
        
        let newLogID = UUID().uuidString
        let newLog: [String: Any] = [
            "id": newLogID,
            "text": text,
            "timestamp": Date(),
            "generatedByUID": generatedByUID,
            "uploaded": false
        ]
        
        if let lastLog = logs.last,
           let lastLogText = lastLog["text"] as? String,
           let lastLogUID = lastLog["generatedByUID"] as? String,
           lastLogUID == generatedByUID {
            
            if text.starts(with: lastLogText), text.count > lastLogText.count {
                logs[logs.count - 1] = newLog
                print("DEBUG_KEYBOARD: Updated last flagged text to: \"\(text)\" in UserDefaults (UID: \(generatedByUID)).")
            } else {
                logs.append(newLog)
                print("DEBUG_KEYBOARD: Appended new flagged text to UserDefaults: \"\(text)\" (UID: \(generatedByUID)).")
            }
        } else {
            logs.append(newLog)
            print("DEBUG_KEYBOARD: Appended first flagged text (or new user) to UserDefaults: \"\(text)\" (UID: \(generatedByUID)).")
        }
        
        defaults.set(logs, forKey: "FlaggedTexts")
        print("DEBUG_KEYBOARD: Total items in UserDefaults 'FlaggedTexts' after save: \(logs.count)")
        
        NotificationCenter.default.post(name: NSNotification.Name("FlaggedTextUpdated"), object: nil)
        print("DEBUG_KEYBOARD: Posted 'FlaggedTextUpdated' notification.")
        
        if let flaggedWord = FlaggedWord(dictionary: newLog) {
            uploadFlaggedTextToFirestore(flaggedWord)
        }
    }
    func uploadFlaggedTextToFirestore(_ flaggedWord: FlaggedWord) {
        let db = Firestore.firestore()
        guard let defaults = UserDefaults(suiteName: appGroupId) else { return }
        
        let childUID = flaggedWord.generatedByUID
        db.collection("users").document(childUID).getDocument { docSnapshot, error in
            guard let data = docSnapshot?.data(),
                  let parentUID = data["parentUID"] as? String, !parentUID.isEmpty else {
                print("KEYBOARD_FIRESTORE: Missing parentUID for user \(childUID)")
                return
            }
            
            let payload: [String: Any] = [
                "id": flaggedWord.id.uuidString,
                "text": flaggedWord.text,
                "timestamp": Timestamp(date: flaggedWord.timestamp),
                "generatedByUID": childUID,
                "parentUID": parentUID
            ]
            
            db.collection("flaggedTexts").document(flaggedWord.id.uuidString).setData(payload) { error in
                if let error = error {
                    print("KEYBOARD_FIRESTORE: Error uploading flagged text: \(error.localizedDescription)")
                } else {
                    print("KEYBOARD_FIRESTORE: Successfully uploaded flagged word \(flaggedWord.id)")
                }
            }
        }
    }
}
