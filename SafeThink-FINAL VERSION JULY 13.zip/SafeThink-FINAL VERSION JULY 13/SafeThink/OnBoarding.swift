import SwiftUI
import Firebase
import FirebaseAuth
import GoogleSignIn
import GoogleSignInSwift
import AuthenticationServices
import CryptoKit
import Foundation
import FirebaseFirestore
import UniformTypeIdentifiers

enum AuthMode {
    case login
    case signup
}

struct ChildProfile: Identifiable, Equatable {
    let id: String
    let email: String
}

@main
struct SafeThinkApp: App {
    @StateObject private var authManager = AuthManager()

    init() {
        FirebaseApp.configure()
        print("FirebaseApp configured.")
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if authManager.isAuthenticated {
                    if authManager.needsEmailVerification {
                        EmailVerificationView()
                            .transition(.opacity)
                    } else if authManager.infoFormCompleted {
                        if authManager.needsKeyboardSetup {
                            NavigationView {
                                KeyboardInstructionView()
                            }
                            .transition(.opacity)
                        } else {
                            MainAppView()
                                .transition(.opacity)
                        }
                    } else {
                        InfoFormView()
                            .transition(.opacity)
                    }
                } else {
                    OnboardingView(authManager: authManager)
                        .transition(.opacity)
                }
            }
            .environmentObject(authManager)
            .animation(.easeInOut(duration: 0.3), value: authManager.isAuthenticated)
            .animation(.easeInOut(duration: 0.3), value: authManager.infoFormCompleted)
            .animation(.easeInOut(duration: 0.3), value: authManager.needsEmailVerification)
            .animation(.easeInOut(duration: 0.3), value: authManager.needsKeyboardSetup)
            .onAppear {
                authManager.checkCurrentUserStatus()
            }
        }
    }
}

class AuthManager: ObservableObject {
    @Published var isAuthenticated: Bool = false
    @Published var infoFormCompleted: Bool = false
    @Published var currentUser: User?
    @Published var needsEmailVerification: Bool = false
    @Published var needsKeyboardSetup: Bool = false
    @Published var isCurrentUserParent: Bool = false
    @Published var pairedUserEmail: String?
    @Published var childrenProfiles: [ChildProfile] = []

    private var authStateDidChangeListenerHandle: AuthStateDidChangeListenerHandle?
    private var firestoreListener: ListenerRegistration?

    init() {
        setupAuthStateListener()
    }

    deinit {
        if let handle = authStateDidChangeListenerHandle {
            Auth.auth().removeStateDidChangeListener(handle)
        }
        firestoreListener?.remove()
    }

    func setupAuthStateListener() {
        authStateDidChangeListenerHandle = Auth.auth().addStateDidChangeListener { [weak self] auth, user in
            DispatchQueue.main.async {
                self?.currentUser = user
                self?.isAuthenticated = (user != nil)
                print("Auth state changed. isAuthenticated: \(self?.isAuthenticated ?? false), User ID: \(user?.uid ?? "nil")")

                self?.firestoreListener?.remove()

                if let user = user {
                    if user.providerData.contains(where: { $0.providerID == EmailAuthProviderID }) {
                        self?.needsEmailVerification = !user.isEmailVerified
                        print("Email user. isEmailVerified: \(user.isEmailVerified)")
                    } else {
                        self?.needsEmailVerification = false
                    }

                    self?.listenToUserDocument(user: user)

                } else {
                    self?.infoFormCompleted = false
                    self?.needsEmailVerification = false
                    self?.needsKeyboardSetup = false
                    self?.isCurrentUserParent = false
                    self?.pairedUserEmail = nil
                    self?.childrenProfiles = []
                }
            }
        }
    }

    func listenToUserDocument(user: User) {
        let db = Firestore.firestore()
        let userDocRef = db.collection("users").document(user.uid)

        firestoreListener = userDocRef.addSnapshotListener { [weak self] documentSnapshot, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                guard let document = documentSnapshot else {
                    print("Error fetching user document: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }

                if document.exists, let data = document.data() {
                    let hasCompletedInfoForm = data["infoFormCompleted"] as? Bool ?? false
                    let isParent = data["isParent"] as? Bool ?? false
                    let hasCompletedOverallOnboarding = data["hasCompletedOverallOnboarding"] as? Bool ?? false
                    let parentUID = data["parentUID"] as? String

                    self.infoFormCompleted = hasCompletedInfoForm
                    self.isCurrentUserParent = isParent
                    
                    print("Firestore user data updated. infoFormCompleted: \(hasCompletedInfoForm), isParent: \(isParent), hasCompletedOverallOnboarding: \(hasCompletedOverallOnboarding)")

                    if self.infoFormCompleted && !self.needsEmailVerification && !self.isCurrentUserParent && !hasCompletedOverallOnboarding {
                        self.needsKeyboardSetup = true
                        print("needsKeyboardSetup for child set to: true")
                    } else {
                        self.needsKeyboardSetup = false
                    }
                    
                    if hasCompletedOverallOnboarding {
                        self.infoFormCompleted = true
                    }

                    if hasCompletedInfoForm {
                        self.fetchRelationshipDetails(isParent: isParent, parentUID: parentUID)
                    } else {
                        self.pairedUserEmail = nil
                        self.childrenProfiles = []
                    }
                } else {
                    self.infoFormCompleted = false
                    self.needsEmailVerification = false
                    self.needsKeyboardSetup = false
                    self.isCurrentUserParent = false
                    self.pairedUserEmail = nil
                    self.childrenProfiles = []
                    print("Firestore user document not found for \(user.uid). Onboarding not completed.")
                }
            }
        }
    }

    func fetchRelationshipDetails(isParent: Bool, parentUID: String?) {
        let db = Firestore.firestore()

        if isParent {
            guard let myUID = currentUser?.uid else { return }
            db.collection("users").whereField("parentUID", isEqualTo: myUID).addSnapshotListener { [weak self] querySnapshot, error in
                DispatchQueue.main.async {
                    if let error = error {
                        print("Error fetching children profiles: \(error.localizedDescription)")
                        self?.childrenProfiles = []
                        return
                    }

                    if let documents = querySnapshot?.documents {
                        let children: [ChildProfile] = documents.compactMap { document in
                            let data = document.data()
                            if let childEmail = data["email"] as? String {
                                return ChildProfile(id: document.documentID, email: childEmail)
                            }
                            return nil
                        }
                        self?.childrenProfiles = children
                    } else {
                        self?.childrenProfiles = []
                    }
                    print("Fetched \(self?.childrenProfiles.count ?? 0) children for parent \(myUID).")
                }
            }
        } else if let pUID = parentUID {
            db.collection("users").document(pUID).getDocument { [weak self] document, error in
                DispatchQueue.main.async {
                    if let error = error {
                        print("Error fetching parent's email: \(error.localizedDescription)")
                        self?.pairedUserEmail = nil
                        return
                    }
                    if let document = document, document.exists, let data = document.data() {
                        self?.pairedUserEmail = data["email"] as? String
                        print("Fetched parent email: \(self?.pairedUserEmail ?? "nil")")
                    } else {
                        self?.pairedUserEmail = nil
                        print("Parent document not found for UID: \(pUID)")
                    }
                }
            }
        } else {
            self.pairedUserEmail = nil
            self.childrenProfiles = []
        }
    }


    func checkCurrentUserStatus() {
        DispatchQueue.main.async {
            self.currentUser = Auth.auth().currentUser
            self.isAuthenticated = (self.currentUser != nil)
            print("Initial user check. isAuthenticated: \(self.isAuthenticated), User ID: \(self.currentUser?.uid ?? "nil")")

            if let user = self.currentUser {
                let sharedDefaults = UserDefaults(suiteName: "group.com.safethink.app")
                    sharedDefaults?.set(user.uid, forKey: "currentUserUID")
                    sharedDefaults?.synchronize()
                    print("DEBUG: Refreshed currentUserUID in shared UserDefaults on app startup: \(user.uid)")
                if user.providerData.contains(where: { $0.providerID == EmailAuthProviderID }) {
                    self.needsEmailVerification = !user.isEmailVerified
                } else {
                    self.needsEmailVerification = false
                }
                
                self.listenToUserDocument(user: user)
                
            } else {
                self.infoFormCompleted = false
                self.needsEmailVerification = false
                self.needsKeyboardSetup = false
                self.isCurrentUserParent = false
                self.pairedUserEmail = nil
                self.childrenProfiles = []
            }
        }
    }
    
    func resendVerificationEmail() async -> String? {
        guard let user = Auth.auth().currentUser else {
            return "No authenticated user to send email to."
        }
        
        do {
            try await user.sendEmailVerification()
            print("Verification email re-sent to \(user.email ?? "user").")
            return "Verification email re-sent! Please check your inbox."
        } catch {
            print("Error re-sending verification email: \(error.localizedDescription)")
            return "Failed to re-send verification email: \(error.localizedDescription)"
        }
    }
    
    func reloadUser() async {
        guard let user = Auth.auth().currentUser else { return }
        do {
            try await user.reload()
            DispatchQueue.main.async {
                if user.providerData.contains(where: { $0.providerID == EmailAuthProviderID }) {
                    let isVerified = user.isEmailVerified
                    self.needsEmailVerification = !isVerified
                    print("User reloaded. isEmailVerified: \(isVerified)")
                }
            }
        } catch {
            print("Error reloading user: \(error.localizedDescription)")
        }
    }

    func signOut() {
        do {
            try Auth.auth().signOut()
            GIDSignIn.sharedInstance.signOut()
            print("User signed out from Firebase and Google.")
            self.infoFormCompleted = false
            self.needsEmailVerification = false
            self.needsKeyboardSetup = false
            self.isCurrentUserParent = false
            self.pairedUserEmail = nil
            self.childrenProfiles = []
            firestoreListener?.remove()
            let appGroupID = "group.com.safethink.app"
            let sharedDefaults = UserDefaults(suiteName: appGroupID)
            sharedDefaults?.removeObject(forKey: "currentUserUID")
            sharedDefaults?.synchronize()
            print("DEBUG: Cleared currentUserUID from shared UserDefaults on sign out.")
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
        }
    }
}

extension Color {
    static let deepPurple = Color(red: 0.3, green: 0.2, blue: 0.5)
    static let authButtonBackground = Color(.systemGray6)
    static let lavenderAccent = Color(red: 0.7, green: 0.7, blue: 0.9)
}

struct UIConstants {
    static let cornerRadius: CGFloat = 10
    static let buttonHeight: CGFloat = 55
    static let fieldPadding: CGFloat = 14
    static let horizontalPadding: CGFloat = 24
    static let verticalSpacing: CGFloat = 18
    static let logoSize: CGFloat = 80.5
    static let progressHeight: CGFloat = 4
    static let largeIconSize: CGFloat = 100
}

struct PrimaryActionButton: View {
    let title: String
    let action: () -> Void
    let isDisabled: Bool
    var backgroundColor: Color = .accentRosePink
    var textColor: Color = .white
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .frame(maxWidth: .infinity)
                .frame(height: UIConstants.buttonHeight)
                .background(isDisabled ? backgroundColor.opacity(0.4) : backgroundColor)
                .foregroundColor(textColor)
                .cornerRadius(UIConstants.cornerRadius)
        }
        .disabled(isDisabled)
        .animation(.easeOut(duration: 0.2), value: isDisabled)
    }
}

struct AuthInputField: View {
    let placeholder: String
    @Binding var text: String
    let isSecure: Bool
    
    private var systemIconName: String? {
        if placeholder.contains("Email") {
            return "envelope"
        } else if placeholder.contains("Password") || placeholder.contains("Confirm password") {
            return "lock"
        }
        return nil
    }
    
    var body: some View {
        HStack(spacing: 12) {
            if let iconName = systemIconName {
                Image(systemName: iconName)
                    .foregroundColor(.grayIcon)
                    .font(.body)
            }
            
            Group {
                if isSecure {
                    SecureField(placeholder, text: $text)
                } else {
                    TextField("", text: $text)
                        .keyboardType(placeholder.contains("Email") ? .emailAddress : .default)
                        .textContentType(placeholder.contains("Email") ? .emailAddress : .init(rawValue: ""))
                        .autocapitalization(.none)
                        .disableAutocorrection(true)
                        .placeholder(when: text.isEmpty) {
                            Text(placeholder)
                                .foregroundColor(.placeholderTextContrast)
                        }
                }
            }
        }
        .padding(.vertical, UIConstants.fieldPadding)
        .padding(.horizontal)
        .background(Color.inputFieldBackground)
        .cornerRadius(UIConstants.cornerRadius)
        .font(.system(size: 17, weight: .regular, design: .rounded))
        .overlay(
            RoundedRectangle(cornerRadius: UIConstants.cornerRadius)
                .stroke(text.isEmpty ? Color.clear : Color.accentRosePink.opacity(0.6), lineWidth: 2)
        )
        .animation(.easeOut(duration: 0.2), value: text.isEmpty)
    }
}

struct SocialAuthButton: View {
    let logoName: String
    let isSystemImage: Bool
    let title: String
    var backgroundColor: Color = .white
    var foregroundColor: Color = .primary
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                if isSystemImage {
                    Image(systemName: logoName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 22, height: 22)
                } else {
                    Image(logoName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 24, height: 24)
                }
                
                Text(title)
                    .fontWeight(.medium)
            }
            .frame(maxWidth: .infinity)
            .frame(height: UIConstants.buttonHeight)
            .background(backgroundColor)
            .foregroundColor(foregroundColor)
            .cornerRadius(UIConstants.cornerRadius)
            .overlay(
                RoundedRectangle(cornerRadius: UIConstants.cornerRadius)
                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
            )
        }
    }
}

struct OnboardingView: View {
    @ObservedObject var authManager: AuthManager
    
    @State private var errorMessage: String?
    @State private var isLoading = false
    @State private var showEmailSheet = false
    @State private var initialAuthMode: AuthMode = .signup
    
    @State private var currentNonce: String?

    var body: some View {
        NavigationStack {
            VStack {
                Spacer()
                
                VStack(spacing: 4) {
                    Image("sthinkoffical-Photoroom")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 200, height: 140)
                    
                    Text("SafeThink")
                        .font(.system(size: 40, weight: .bold, design: .rounded))
                        .foregroundColor(.pinkTitleContrast)
                }
                .padding(.bottom, 60)
                
                VStack(spacing: UIConstants.verticalSpacing) {
                    SocialAuthButton(logoName: "google_logo", isSystemImage: false, title: "Continue with Google", action: signInWithGoogle)
                    
                    SocialAuthButton(logoName: "apple.logo", isSystemImage: true, title: "Continue with Apple", backgroundColor: .black, foregroundColor: .white, action: signInWithApple)

                    SocialAuthButton(logoName: "envelope.fill", isSystemImage: true, title: "Continue with Email", action: {
                        initialAuthMode = .signup
                        showEmailSheet = true
                    })
                }
                .padding(.horizontal, UIConstants.horizontalPadding)
                
                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.footnote)
                        .multilineTextAlignment(.center)
                        .padding()
                }
                
                Spacer()
                
                Button(action: {
                    initialAuthMode = .login
                    showEmailSheet = true
                }) {
                    Text("Already have an account? **Sign In**")
                        .font(.callout)
                        .foregroundColor(.secondaryTextContrast)
                }
                .padding(.bottom, 20)
            }
            .background(Color(.systemBackground).edgesIgnoringSafeArea(.all))
            .sheet(isPresented: $showEmailSheet) {
                EmailAuthView(initialAuthMode: initialAuthMode, errorMessage: $errorMessage)
            }
            .overlay(
                Group {
                    if isLoading {
                        Color.black.opacity(0.4)
                            .edgesIgnoringSafeArea(.all)
                        ProgressView("Please wait...")
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                    }
                }
            )
        }
    }
    
    func signInWithGoogle() {
        isLoading = true
        errorMessage = nil
        
        guard let clientID = FirebaseApp.app()?.options.clientID else {
            errorMessage = "Missing Firebase client ID for Google Sign-In."
            isLoading = false
            return
        }
        
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        guard let presentingViewController = getRootViewController() else {
            errorMessage = "Could not get root view controller for Google Sign-In."
            isLoading = false
            return
        }
        
        let db = Firestore.firestore()

        GIDSignIn.sharedInstance.signIn(withPresenting: presentingViewController) { signInResult, error in
            DispatchQueue.main.async {
                if let error = error as NSError?, error.code == GIDSignInError.canceled.rawValue {
                    print("Google Sign-In was cancelled by the user.")
                    self.isLoading = false
                    return
                }
                
                if let error = error {
                    print("Google Sign-in error: \(error.localizedDescription)")
                    self.errorMessage = "Google Sign-In failed: \(error.localizedDescription)"
                    self.isLoading = false
                    return
                }
                
                guard let user = signInResult?.user, let idToken = user.idToken?.tokenString else {
                    self.errorMessage = "Google authentication data missing."
                    self.isLoading = false
                    return
                }
                
                let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: user.accessToken.tokenString)
                
                Auth.auth().signIn(with: credential) { authResult, error in
                    DispatchQueue.main.async {
                        self.isLoading = false
                        if let error = error {
                            self.errorMessage = "Firebase auth with Google failed: \(error.localizedDescription)"
                        } else if let user = authResult?.user {
                            db.collection("users").document(user.uid).setData(["email": user.email ?? "N/A"], merge: true)
                            let sharedDefaults = UserDefaults(suiteName: "group.com.safethink.app")
                            sharedDefaults?.set(user.uid, forKey: "currentUserUID")
                            sharedDefaults?.synchronize()
                        }
                    }
                }
            }
        }
    }

    func signInWithApple() {
        isLoading = true
        errorMessage = nil
        let nonce = randomNonceString()
        currentNonce = nonce
        
        print("DEBUG: Initiating Apple Sign-In request.")
        let appleIDProvider = ASAuthorizationAppleIDProvider()
        let request = appleIDProvider.createRequest()
        request.requestedScopes = [.fullName, .email]
        request.nonce = sha256(nonce)

        let authorizationController = ASAuthorizationController(authorizationRequests: [request])
        authorizationController.delegate = makeCoordinator()
        authorizationController.presentationContextProvider = makeCoordinator()
        authorizationController.performRequests()
        print("DEBUG: ASAuthorizationController.performRequests() called.")
    }

    private func makeCoordinator() -> AppleSignInCoordinator {
        return AppleSignInCoordinator(self)
    }
    
    class AppleSignInCoordinator: NSObject, ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
        var parent: OnboardingView

        init(_ parent: OnboardingView) {
            self.parent = parent
        }

        func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
            print("DEBUG: presentationAnchor called.")
            return getRootViewController()!.view.window!
        }

        func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
            print("DEBUG: authorizationController didCompleteWithAuthorization called.")
            defer { self.parent.isLoading = false }

            guard let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential else {
                parent.errorMessage = "Apple Sign-In failed: Invalid credential."
                print("ERROR: Apple Sign-In failed: Invalid credential.")
                return
            }
            
            guard let nonce = parent.currentNonce else {
                parent.errorMessage = "Apple Sign-In failed: Missing nonce."
                print("ERROR: Apple Sign-In failed: Missing nonce.")
                return
            }
            
            guard let appleIDToken = appleIDCredential.identityToken else {
                parent.errorMessage = "Apple Sign-In failed: Missing identity token."
                print("ERROR: Apple Sign-In failed: Missing identity token.")
                return
            }
            
            guard let idTokenString = String(data: appleIDToken, encoding: .utf8) else {
                parent.errorMessage = "Apple Sign-In failed: Could not decode token."
                print("ERROR: Apple Sign-In failed: Could not decode token.")
                return
            }

            let credential = OAuthProvider.appleCredential(withIDToken: idTokenString,
                                                           rawNonce: nonce,
                                                           fullName: appleIDCredential.fullName)
            
            print("DEBUG: Attempting Firebase sign-in with Apple credential.")
            Auth.auth().signIn(with: credential) { (authResult, error) in
                DispatchQueue.main.async {
                    print("DEBUG: Firebase signIn completion handler called.")
                    if let error = error {
                        self.parent.errorMessage = "Firebase auth with Apple failed: \(error.localizedDescription)"
                        print("ERROR: Firebase auth with Apple failed: \(error.localizedDescription)")
                        return
                    }
                    
                    guard let user = authResult?.user else {
                        self.parent.errorMessage = "Firebase auth with Apple completed without user or error. Please try again."
                        print("ERROR: Firebase auth with Apple completed without user or error.")
                        return
                    }

                    let db = Firestore.firestore()
                    let emailToStore = user.email ?? "N/A_Email_Not_Provided"
                    
                    print("DEBUG: Attempting to set user data in Firestore for UID: \(user.uid) with email: \(emailToStore)")
                    Task {
                        do {
                            try await db.collection("users").document(user.uid).setData(["email": emailToStore], merge: true)
                            print("DEBUG: User data set successfully in Firestore.")
                            let sharedDefaults = UserDefaults(suiteName: "group.com.safethink.app")
                            sharedDefaults?.set(user.uid, forKey: "currentUserUID")
                            sharedDefaults?.synchronize()
                            print("DEBUG: currentUserUID refreshed in shared UserDefaults.")
                        } catch {
                            self.parent.errorMessage = "Setup failed: Could not save user data. \(error.localizedDescription)"
                            print("ERROR: Failed to set user data in Firestore: \(error.localizedDescription)")
                        }
                    }
                }
            }
        }

        func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
            DispatchQueue.main.async {
                print("DEBUG: authorizationController didCompleteWithError called. Error: \(error.localizedDescription)")
                self.parent.isLoading = false

                let nsError = error as NSError
                if nsError.code == ASAuthorizationError.canceled.rawValue {
                     print("Apple Sign-In cancelled by user.")
                } else if nsError.domain == ASAuthorizationError.errorDomain && nsError.code == 1000 {
                    self.parent.errorMessage = "Apple Sign-In failed. This often happens if the 'Sign In with Apple' capability is not correctly enabled in Xcode, or if there's an issue with your Apple Developer account setup. Please check Xcode's 'Signing & Capabilities' and try again, preferably on a physical device."
                } else if nsError.domain == "AKAuthenticationError" && nsError.code == -7026 {
                    self.parent.errorMessage = "Apple Sign-In failed (Code -7026). This usually indicates a problem with your Apple ID or the environment. Try signing out and back into your Apple ID on the device/simulator, or test on a physical device."
                }
                else {
                    self.parent.errorMessage = "Apple Sign-In failed: \(error.localizedDescription)"
                }
            }
        }
    }
}

func getRootViewController() -> UIViewController? {
    guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
          let root = scene.windows.first?.rootViewController else {
        return nil
    }
    var topController = root
    while let presentedVC = topController.presentedViewController {
        topController = presentedVC
    }
    return topController
}

struct EmailAuthView: View {
    let initialAuthMode: AuthMode
    @Binding var errorMessage: String?
    
    @EnvironmentObject var authManager: AuthManager
    @Environment(\.dismiss) private var dismiss
    
    @State private var authMode: AuthMode
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var successMessage: String?
    @State private var isLoading = false
    
    init(initialAuthMode: AuthMode, errorMessage: Binding<String?>) {
        self.initialAuthMode = initialAuthMode
        self._authMode = State(initialValue: initialAuthMode)
        self._errorMessage = errorMessage
    }
    
    var body: some View {
        NavigationView {
            VStack(spacing: UIConstants.verticalSpacing) {
                
                Text(authMode == .login ? "" : "")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.bottom, 20)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, UIConstants.horizontalPadding)
                
                Picker("Mode", selection: $authMode) {
                    Text("Sign Up").tag(AuthMode.signup)
                    Text("Sign In").tag(AuthMode.login)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                .padding(.bottom, 20)
                .onChange(of: authMode) { _ in clearMessages() }

                AuthInputField(placeholder: "Email address", text: $email, isSecure: false)
                AuthInputField(placeholder: "Password (6+ characters)", text: $password, isSecure: true)
                if authMode == .signup {
                    AuthInputField(placeholder: "Confirm password", text: $confirmPassword, isSecure: true)
                }
                
                if let msg = errorMessage {
                    Text(msg).foregroundColor(.red).font(.footnote).multilineTextAlignment(.center)
                } else if let msg = successMessage {
                    Text(msg).foregroundColor(.green).font(.footnote).multilineTextAlignment(.center)
                }
                
                PrimaryActionButton(
                    title: authMode == .login ? "Sign In" : "Create Account",
                    action: authenticateWithEmail,
                    isDisabled: isLoading,
                    backgroundColor: .buttonRosePink
                )
                .padding(.top, UIConstants.verticalSpacing * 0.75)

                Spacer(minLength: 40)
            }
            .padding(.horizontal, UIConstants.horizontalPadding)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") { dismiss() }
                        .font(.body)
                        .foregroundColor(.accentRosePink)
                        .padding(.top, 10)
                }
            }
            .onChange(of: email) { _ in clearMessages() }
            .onChange(of: password) { _ in clearMessages() }
            .onChange(of: confirmPassword) { _ in clearMessages() }
        }
    }
    
    private func clearMessages() {
        errorMessage = nil
        successMessage = nil
    }
    
    private func authenticateWithEmail() {
        clearMessages()
        isLoading = true
        
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        
        guard cleanEmail.isValidEmail else {
            errorMessage = "Please enter a valid email address."
            isLoading = false
            return
        }
        
        let db = Firestore.firestore()

        if authMode == .signup {
            guard password == confirmPassword else {
                errorMessage = "Passwords do not match."
                isLoading = false
                return
            }
            guard password.count >= 6 else {
                errorMessage = "Password must be at least 6 characters."
                isLoading = false
                return
            }
            
            Auth.auth().createUser(withEmail: cleanEmail, password: password) { authResult, error in
                if let user = authResult?.user {
                    user.sendEmailVerification { err in
                        isLoading = false
                        if let err = err {
                            errorMessage = "Failed to send verification email: \(err.localizedDescription)"
                        } else {
                            db.collection("users").document(user.uid).setData(["email": cleanEmail], merge: true)
                            let sharedDefaults = UserDefaults(suiteName: "group.com.safethink.app")
                            sharedDefaults?.set(user.uid, forKey: "currentUserUID")
                            sharedDefaults?.synchronize()
                            dismiss()
                        }
                    }
                } else if let error = error {
                    errorMessage = "Signup failed: \((error as NSError).localizedDescription)"
                    isLoading = false
                }
            }
        } else {
            Auth.auth().signIn(withEmail: cleanEmail, password: password) { authResult, error in
                isLoading = false
                if let error = error {
                    errorMessage = "Login failed: \((error as NSError).localizedDescription)"
                } else if let user = authResult?.user {
                    db.collection("users").document(user.uid).setData(["email": cleanEmail], merge: true)
                    let sharedDefaults = UserDefaults(suiteName: "group.com.safethink.app")
                    sharedDefaults?.set(user.uid, forKey: "currentUserUID")
                    sharedDefaults?.synchronize()
                    dismiss()
                }
            }
        }
    }
}

extension String {
    var isValidEmail: Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPredicate.evaluate(with: self)
    }
}

struct EmailVerificationView: View {
    @EnvironmentObject var authManager: AuthManager
    @State private var feedbackMessage: String?
    @State private var isCheckingStatus = false
    @State private var isResendingEmail = false

    private var isLoading: Bool {
        isCheckingStatus || isResendingEmail
    }
    
    var body: some View {
        VStack(spacing: 0) {
            Spacer()

            VStack(spacing: 12) {
                Image(systemName: "envelope.open.fill")
                    .font(.system(size: 60))
                    .foregroundColor(.accentRosePink.opacity(0.8))

                Text("Verify Your Email")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundColor(.primary)

                Text("A verification link was sent to **\(authManager.currentUser?.email ?? "your inbox")**. Please click the link to activate your account.")
                    .font(.system(size: 17, weight: .regular, design: .rounded))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
                    .lineSpacing(4)
            }
            .padding(.horizontal, UIConstants.horizontalPadding)
            
            Spacer()

            if let message = feedbackMessage {
                Text(message)
                    .font(.footnote)
                    .foregroundColor(message.contains("Failed") || message.contains("still not verified") ? .red : .green)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, UIConstants.horizontalPadding)
                    .padding(.bottom, UIConstants.verticalSpacing)
                    .transition(.opacity.animation(.easeInOut))
            }

            VStack(spacing: 12) {
                Button(action: {
                    Task {
                        isCheckingStatus = true
                        await authManager.reloadUser()
                        isCheckingStatus = false
                        if authManager.needsEmailVerification {
                            feedbackMessage = "Email still not verified. Please check your inbox and spam folder."
                        }
                    }
                }) {
                    HStack {
                        if isCheckingStatus {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                        } else {
                            Text("I've Verified My Email")
                        }
                    }
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .frame(height: UIConstants.buttonHeight)
                    .background(Color.accentRosePink)
                    .foregroundColor(.white)
                    .cornerRadius(UIConstants.cornerRadius)
                }
                .disabled(isLoading)

                Button(action: {
                    Task {
                        isResendingEmail = true
                        feedbackMessage = await authManager.resendVerificationEmail()
                        isResendingEmail = false
                    }
                }) {
                    HStack {
                        if isResendingEmail {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .accentRosePink))
                        } else {
                            Text("Resend Verification Email")
                        }
                    }
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .frame(height: UIConstants.buttonHeight)
                    .foregroundColor(.accentRosePink)
                    .cornerRadius(UIConstants.cornerRadius)
                    .overlay(
                        RoundedRectangle(cornerRadius: UIConstants.cornerRadius)
                            .stroke(Color.accentRosePink, lineWidth: 1.5)
                    )
                }
                .disabled(isLoading)
            }
            .padding(.horizontal, UIConstants.horizontalPadding)

            Button("Sign Out") {
                authManager.signOut()
            }
            .font(.subheadline)
            .foregroundColor(.gray)
            .padding(.vertical, 30)
            .disabled(isLoading)
        }
        .background(Color(.systemBackground).ignoresSafeArea())
        .animation(.easeInOut, value: isLoading)
        .animation(.easeInOut, value: feedbackMessage)
    }
}

extension View {
    func placeholder<Content: View>(
        when shouldShow: Bool,
        alignment: Alignment = .leading,
        @ViewBuilder placeholder: () -> Content) -> some View {
        
        ZStack(alignment: alignment) {
            placeholder().opacity(shouldShow ? 1 : 0)
            self
        }
    }
    
    @ViewBuilder func `if`<Content: View>(_ condition: Bool, transform: (Self) -> Content) -> some View {
        if condition {
            transform(self)
        } else {
            self
        }
    }
}

struct InfoFormView: View {
    @EnvironmentObject var authManager: AuthManager
    @State private var birthday = Calendar.current.date(byAdding: .year, value: -18, to: Date())!
    @State private var generatedPairingCode = ""
    @State private var childPairingCodeInput = ""
    @FocusState private var isPairingCodeFocused: Bool
    
    @State private var isParent = true
    @State private var feedbackMessage: (text: String, isError: Bool)?
    @State private var showProgress = false
    @State private var showBirthdayPicker = false

    private var age: Int {
        Calendar.current.dateComponents([.year], from: birthday, to: Date()).year ?? 0
    }
    
    private var formattedBirthday: String {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter.string(from: birthday)
    }

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 16) {
                Text("Step 1 of 2")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundColor(.secondary)
                
                Text("Your Information")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundColor(.pinkTitleContrast)

                Capsule()
                    .fill(Color.gray.opacity(0.2))
                    .frame(height: 4)
                    .overlay(alignment: .leading) {
                        GeometryReader { geo in
                            Capsule()
                                .fill(Color.accentRosePink)
                                .frame(width: geo.size.width * 0.5)
                        }
                    }
            }
            .padding(.horizontal, 40)
            .padding(.top, 20)
            .padding(.bottom, 25)

            ScrollView(showsIndicators: false) {
                VStack(spacing: 24) {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Birthday").font(.headline).foregroundColor(.secondary)
                        Button(action: { showBirthdayPicker = true }) {
                            HStack {
                                Text(formattedBirthday)
                                    .font(.system(size: 17, design: .rounded))
                                    .foregroundColor(.primary)
                                Spacer()
                                Image(systemName: "calendar")
                                    .foregroundColor(.lavenderAccent)
                            }
                            .padding().background(Color.inputFieldBackground).cornerRadius(10)
                        }
                        Text("Age: \(age)").font(.caption).foregroundColor(.secondary)
                    }
                    .padding(20).cardBackground()

                    if isParent { parentView } else { childView }
                    
                    if let msg = feedbackMessage {
                        Text(msg.text).font(.footnote).bold()
                            .foregroundColor(msg.isError ? .red : .green)
                            .multilineTextAlignment(.center).padding(.horizontal)
                    }
                }
                .padding(.horizontal, 24).padding(.top, 12)
            }

            Spacer(minLength: 20)

            Button(action: { Task { await completeSection1() } }) {
                Text("Continue")
                    .font(.headline)
                    .frame(width: 300, height: UIConstants.buttonHeight)
                    .background(isFormValid && !showProgress ? Color.accentRosePink : Color.accentRosePink.opacity(0.5))
                    .foregroundColor(.white).clipShape(Capsule())
                    .shadow(color: isFormValid && !showProgress ? Color.accentRosePink.opacity(0.35) : .clear, radius: 8, x: 0, y: 5)
            }
            .disabled(!isFormValid || showProgress)
            .padding(.top, 5)
            .padding(.bottom, 30)
        }
        .background(Color.white.ignoresSafeArea())
        .tint(Color.accentRosePink)
        .overlay(progressOverlay)
        .sheet(isPresented: $showBirthdayPicker) {
            BirthdayPickerView(birthday: $birthday)
        }
        .onAppear { isParent = age >= 18 }
        .onChange(of: birthday) { _ in
            isParent = age >= 18; feedbackMessage = nil; generatedPairingCode = ""
        }
    }
    
    private var parentView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Pairing Code").font(.headline).foregroundColor(.secondary)
            Text("Generate a 6-digit code for your child to use when they sign up.").font(.footnote).foregroundColor(.secondary)

            if !generatedPairingCode.isEmpty {
                HStack(spacing: 0) {
                    Text(generatedPairingCode).font(.system(size: 24, weight: .bold, design: .monospaced))
                        .frame(maxWidth: .infinity).padding(.vertical, 12).background(Color.inputFieldBackground)
                        .cornerRadius(10, corners: [.topLeft, .bottomLeft])
                    Button(action: {
                        UIPasteboard.general.string = generatedPairingCode
                        feedbackMessage = ("Code copied to clipboard!", false)
                    }) {
                        Image(systemName: "doc.on.doc.fill").foregroundColor(.white).padding()
                            .background(Color.accentRosePink).cornerRadius(10, corners: [.topRight, .bottomRight])
                    }
                }
            }
            PrimaryActionButton(title: "Generate New Code", action: { Task { await generatePairingCode() } }, isDisabled: showProgress)
        }
        .padding(20).cardBackground()
    }
    
    private var childView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Parent's Code").font(.headline).foregroundColor(.secondary)
            Text("Enter the 6-digit code provided by your parent.").font(.footnote).foregroundColor(.secondary)

            TextField("123456", text: $childPairingCodeInput)
                .font(.system(size: 24, weight: .bold, design: .monospaced))
                .keyboardType(.numberPad).multilineTextAlignment(.center).padding()
                .background(Color.inputFieldBackground).cornerRadius(10).focused($isPairingCodeFocused)
                .onChange(of: childPairingCodeInput) { newValue in
                    if newValue.count > 6 { childPairingCodeInput = String(newValue.prefix(6)) }
                    feedbackMessage = nil
                }
        }
        .padding(20).cardBackground()
    }
    
    @ViewBuilder private var progressOverlay: some View {
        if showProgress {
            Color.black.opacity(0.4).edgesIgnoringSafeArea(.all)
            ProgressView("Processing...").padding().background(Color.white).cornerRadius(10).shadow(radius: 5)
        }
    }

    var isFormValid: Bool {
        if isParent { return !generatedPairingCode.isEmpty }
        else { return childPairingCodeInput.count == 6 }
    }

    func generatePairingCode() async {
        showProgress = true; feedbackMessage = nil
        guard let parentUID = Auth.auth().currentUser?.uid else {
            feedbackMessage = ("Error: User not authenticated.", true); showProgress = false; return
        }

        let db = Firestore.firestore()
        let newCode = String(format: "%06d", Int.random(in: 100000...999999))
        let codeData: [String: Any] = ["code": newCode, "parentUID": parentUID, "generatedAt": Timestamp(), "expiresAt": Timestamp(date: Date().addingTimeInterval(36000)), "isUsed": false]

        do {
            try await db.collection("pairingCodes").document(newCode).setData(codeData)
            DispatchQueue.main.async { self.generatedPairingCode = newCode }
        } catch {
            DispatchQueue.main.async { self.feedbackMessage = ("Error generating code.", true) }
        }
        showProgress = false
    }

    func completeSection1() async {
        feedbackMessage = nil; showProgress = true
        guard let uid = Auth.auth().currentUser?.uid else {
            feedbackMessage = ("Error: User not authenticated.", true); showProgress = false; return
        }
        
        let db = Firestore.firestore(); let userDocRef = db.collection("users").document(uid)
        var userData: [String: Any] = ["birthdayTimestamp": birthday.timeIntervalSince1970, "isParent": isParent, "infoFormCompleted": true, "hasCompletedOverallOnboarding": false]

        do {
            if isParent {
                userData["hasCompletedOverallOnboarding"] = true
                try await userDocRef.setData(userData, merge: true)
            } else {
                let codeDocRef = db.collection("pairingCodes").document(childPairingCodeInput)
                let document = try await codeDocRef.getDocument()
                
                guard document.exists, let data = document.data() else {
                    feedbackMessage = ("Invalid pairing code.", true); showProgress = false; return
                }
                guard let expiryDate = (data["expiresAt"] as? Timestamp)?.dateValue(), expiryDate > Date() else {
                    feedbackMessage = ("Pairing code has expired.", true); showProgress = false; return
                }
                guard !(data["isUsed"] as? Bool ?? false) else {
                    feedbackMessage = ("This code has already been used.", true); showProgress = false; return
                }
                guard let validParentUID = data["parentUID"] as? String else {
                    feedbackMessage = ("Invalid pairing code data.", true); showProgress = false; return
                }
                
                userData["parentUID"] = validParentUID
                try await userDocRef.setData(userData, merge: true)
                try await codeDocRef.updateData(["isUsed": true])
            }
        } catch {
            feedbackMessage = ("Error completing setup: \(error.localizedDescription)", true)
        }
        showProgress = false
    }
}

struct BirthdayPickerView: View {
    @Binding var birthday: Date
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationView {
            VStack {
                DatePicker("Select your birthday", selection: $birthday, in: ...Date(), displayedComponents: .date)
                    .datePickerStyle(.graphical)
                    .padding()
                Spacer()
            }
            .navigationTitle("Select Birthday")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") { dismiss() }.fontWeight(.bold)
                }
                      }
                  }
                  .tint(Color.accentRosePink)
              }
          }

extension View {
    func cardBackground() -> some View {
        self.background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(Color(.secondarySystemGroupedBackground))
                .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
        )
    }
    
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners

    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

struct KeyboardInstructionView: View {
    @EnvironmentObject var authManager: AuthManager
    
    @State private var acceptedTerms = false
    @State private var acceptedPrivacy = false
    @State private var isProcessing = false

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 16) {
                Text("Step 2 of 2")
                    .font(.system(size: 14, weight: .medium, design: .rounded))
                    .foregroundColor(.secondary)
                
                Text("Activate Keyboard")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundColor(.pinkTitleContrast)

                Capsule()
                    .fill(Color.gray.opacity(0.2))
                    .frame(height: 4)
                    .overlay(alignment: .leading) {
                        GeometryReader { geo in
                            Capsule()
                                .fill(Color.accentRosePink)
                                .frame(width: geo.size.width)
                        }
                    }
            }
            .padding(.horizontal, 40)
            .padding(.top, 20)
            .padding(.bottom, 25)

            VStack(alignment: .leading, spacing: 18) {
                InstructionStep(number: 1, text: "**Open** the Settings app")
                InstructionStep(number: 2, text: "Go to **General → Keyboard → Keyboards**")
                InstructionStep(number: 3, text: "Tap **Add New Keyboard…** and select **SafeThink**")
                InstructionStep(number: 4, text: "Tap **SafeThink** and enable **Allow Full Access**")
            }
            .padding(24)
            .frame(maxWidth: .infinity)
            .background(RoundedRectangle(cornerRadius: 16).fill(Color.white).shadow(color: .black.opacity(0.06), radius: 12, x: 0, y: 8))
            .padding(.horizontal, 20)
            .padding(.top, 28)

            VStack(spacing: 18) {
                HStack {
                    CheckBoxView(isChecked: $acceptedTerms)
                    Text("I agree to the Terms of Service")
                        .font(.system(size: 17, design: .rounded))
                        .foregroundColor(Color.black.opacity(0.7))
                    Spacer()
                }
                HStack {
                    CheckBoxView(isChecked: $acceptedPrivacy)
                    Text("I agree to the Privacy Policy")
                        .font(.system(size: 17, design: .rounded))
                        .foregroundColor(Color.black.opacity(0.7))
                    Spacer()
                }
            }
            .padding(24)
            .frame(maxWidth: .infinity)
            .background(RoundedRectangle(cornerRadius: 16).fill(Color.white).shadow(color: .black.opacity(0.06), radius: 12, x: 0, y: 8))
            .padding(.horizontal, 20)
            .padding(.top, 16)

            Spacer(minLength: 20)

            Button(action: {
                Task {
                    isProcessing = true
                    await completeOnboardingForChild()
                    isProcessing = false
                }
            }) {
                Text("Continue")
                    .font(.headline)
                    .frame(width: 280)
                    .padding(.vertical, 16)
                    .background((acceptedTerms && acceptedPrivacy) && !isProcessing ? Color.accentRosePink : Color.accentRosePink.opacity(0.5))
                    .foregroundColor(.white)
                    .clipShape(Capsule())
                    .shadow(color: (acceptedTerms && acceptedPrivacy) ? Color.accentRosePink.opacity(0.35) : .clear, radius: 10, x: 0, y: 6)
            }
            .disabled(!(acceptedTerms && acceptedPrivacy) || isProcessing)
            .padding(.bottom, 40)
            .frame(maxWidth: .infinity, alignment: .center)
        }
        .background(Color.white.ignoresSafeArea())
    }

    private func completeOnboardingForChild() async {
        guard let uid = Auth.auth().currentUser?.uid, !authManager.isCurrentUserParent else {
            return
        }

        let db = Firestore.firestore()
        do {
            try await db.collection("users").document(uid).updateData(["hasCompletedOverallOnboarding": true])
        } catch {
            print("Error updating hasCompletedOverallOnboarding for child: \(error.localizedDescription)")
        }
    }
}

struct InstructionStep: View {
    let number: Int
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Text("\(number).")
                .font(.system(size: 18, weight: .semibold, design: .rounded))
                .foregroundColor(Color.accentRosePink)
                .frame(width: 26, alignment: .leading)

            Text(.init(text))
                .font(.system(size: 17, design: .rounded))
                .foregroundColor(Color.black.opacity(0.7))
                .multilineTextAlignment(.leading)
        }
    }
}

struct CheckBoxView: View {
    @Binding var isChecked: Bool

    var body: some View {
        Button(action: {
            isChecked.toggle()
        }) {
            Image(systemName: isChecked ? "checkmark.square.fill" : "square")
                .resizable()
                .frame(width: 24, height: 24)
                .foregroundColor(isChecked ? .accentRosePink : .gray)
        }
        .buttonStyle(.plain)
    }
}

private func sha256(_ input: String) -> String {
    let inputData = Data(input.utf8)
    let hashed = SHA256.hash(data: inputData)
    let hashString = hashed.compactMap {
        return String(format: "%02x", $0)
    }.joined()
    
    return hashString
}

private func randomNonceString(length: Int = 32) -> String {
    precondition(length > 0)
    let charset: [Character] =
        Array("0123456789ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvwxyz-._")
    var result = ""
    var remainingLength = length
    
    while remainingLength > 0 {
        let randoms: [UInt8] = (0 ..< 16).map { _ in
            var random: UInt8 = 0
            let errorCode = SecRandomCopyBytes(kSecRandomDefault, 1, &random)
            if errorCode != errSecSuccess {
                fatalError("Unable to generate nonce. SecRandomCopyBytes failed with OSStatus \(errorCode)")
            }
            return random
        }
        
        randoms.forEach { random in
            if remainingLength == 0 {
                return
            }
            
            if random < charset.count {
                result.append(charset[Int(random)])
                remainingLength -= 1
            }
        }
    }
    
    return result
}

extension Color {
    static let accentRosePink = Color(red: 1.0, green: 0.7, blue: 0.8)

    static let pinkTitleContrast = Color(red: 0.85, green: 0.5, blue: 0.6)

    static let secondaryTextContrast = Color.gray.opacity(0.8)
    
    static let buttonRosePink = Color(red: 0.95, green: 0.6, blue: 0.7)
    
    static let inputFieldBackground = Color(.systemGray6).opacity(0.6)

    static let grayIcon = Color.gray.opacity(0.7)

    static let placeholderTextContrast = Color.gray.opacity(0.6)
}
