import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore
import Charts

struct MainAppView: View {
    @EnvironmentObject var authManager: AuthManager

    var body: some View {
        if authManager.isCurrentUserParent {
            TabView {
                DashboardView()
                    .tabItem {
                        Label("Today", systemImage: "sparkle")
                    }

                SettingsView()
                    .tabItem {
                        Label("Settings", systemImage: "gearshape")
                    }
            }
            .accentColor(.accentRosePink)
        } else {
            SettingsView()
        }
    }
}

struct FlaggedWord: Identifiable, Codable, Equatable {
    let id: UUID
    let text: String
    let timestamp: Date
    let generatedByUID: String
    var uploadedToFirestore: Bool
    var parentUID: String?

    init?(dictionary: [String: Any]) {
        guard let text = dictionary["text"] as? String,
              let timestampAny = dictionary["timestamp"] else {
            return nil
        }

        let timestamp: Date
        if let date = timestampAny as? Date {
            timestamp = date
        } else if let firebaseTimestamp = timestampAny as? Timestamp {
            timestamp = firebaseTimestamp.dateValue()
        } else {
            return nil
        }

        let idString = dictionary["id"] as? String ?? UUID().uuidString
        self.id = UUID(uuidString: idString) ?? UUID()

        self.text = text
        self.timestamp = timestamp
        self.generatedByUID = dictionary["generatedByUID"] as? String ?? "unauthenticated"
        self.uploadedToFirestore = dictionary["uploaded"] as? Bool ?? false
        self.parentUID = dictionary["parentUID"] as? String
    }

    func toDictionary() -> [String: Any] {
        var dict: [String: Any] = [
            "id": id.uuidString,
            "text": text,
            "timestamp": Timestamp(date: timestamp),
            "generatedByUID": generatedByUID,
            "uploaded": uploadedToFirestore
        ]
        if let parent = parentUID, !parent.isEmpty {
            dict["parentUID"] = parent
        }
        return dict
    }

    init(id: UUID = UUID(), text: String, timestamp: Date, generatedByUID: String, uploadedToFirestore: Bool, parentUID: String? = nil) {
        self.id = id
        self.text = text
        self.timestamp = timestamp
        self.generatedByUID = generatedByUID
        self.uploadedToFirestore = uploadedToFirestore
        self.parentUID = parentUID
    }

    enum CodingKeys: String, CodingKey {
        case id
        case text
        case timestamp
        case generatedByUID
        case uploadedToFirestore = "uploaded"
        case parentUID
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.id = try container.decode(UUID.self, forKey: .id)
        self.text = try container.decode(String.self, forKey: .text)

        let firebaseTimestamp = try container.decode(Timestamp.self, forKey: .timestamp)
        self.timestamp = firebaseTimestamp.dateValue()

        self.generatedByUID = try container.decode(String.self, forKey: .generatedByUID)
        self.uploadedToFirestore = try container.decodeIfPresent(Bool.self, forKey: .uploadedToFirestore) ?? false
        self.parentUID = try container.decodeIfPresent(String.self, forKey: .parentUID)
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(text, forKey: .text)
        try container.encode(Timestamp(date: timestamp), forKey: .timestamp)
        try container.encode(generatedByUID, forKey: .generatedByUID)
        try container.encode(uploadedToFirestore, forKey: .uploadedToFirestore)
        try container.encodeIfPresent(parentUID, forKey: .parentUID)
    }
}

struct ToxicStat: Identifiable {
    let id = UUID()
    let date: Date
    let count: Int
}

struct DashboardView: View {
    @EnvironmentObject var authManager: AuthManager
    @State private var flaggedWords: [FlaggedWord] = []
    @State private var stats: [ToxicStat] = []

    @State private var listener: ListenerRegistration?

    let appGroupId = "group.com.safethink.app"

    var body: some View {
        NavigationView {
            ScrollViewReader { scrollViewProxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 24) {
                        VStack(alignment: .leading) {
                            Text("")
                                .font(.title2.bold())
                                .foregroundColor(.black.opacity(0.85))
                                .padding(.horizontal, 20)
                                .padding(.top, 10)

                            if stats.isEmpty {
                                Text("No sufficient data for chart.")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                                    .padding(.horizontal, 20)
                                    .padding(.top, 5)
                            } else {
                                Chart(stats) { stat in
                                    AreaMark(
                                        x: .value("Date", stat.date, unit: .day),
                                        y: .value("Count", stat.count)
                                    )
                                    .interpolationMethod(.monotone)
                                    .foregroundStyle(
                                        LinearGradient(
                                            gradient: Gradient(colors: [Color.accentRosePink.opacity(0.4), .clear]),
                                            startPoint: .top,
                                            endPoint: .bottom
                                        )
                                    )

                                    LineMark(
                                        x: .value("Date", stat.date, unit: .day),
                                        y: .value("Count", stat.count)
                                    )
                                    .interpolationMethod(.monotone)
                                    .foregroundStyle(Color.accentRosePink)

                                    PointMark(
                                        x: .value("Date", stat.date, unit: .day),
                                        y: .value("Count", stat.count)
                                    )
                                    .foregroundStyle(Color.accentRosePink)
                                    .annotation(position: .top, alignment: .center) {
                                        if stat.count > 0 {
                                            Text("\(stat.count)")
                                                .font(.caption)
                                                .foregroundColor(.secondary)
                                        }
                                    }
                                }
                                .chartXAxis {
                                    AxisMarks(values: .stride(by: .day)) { _ in
                                        AxisGridLine()
                                        AxisTick()
                                        AxisValueLabel(format: .dateTime.weekday(.narrow), centered: true)
                                    }
                                }
                                .chartYAxis {
                                    AxisMarks(position: .leading)
                                }
                                .frame(height: 200)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 16).fill(Color.white).shadow(color: .black.opacity(0.06), radius: 12, x: 0, y: 8))
                                .padding(.horizontal)
                            }
                        }

                        HStack {
                            Text("")
                                .font(.title3.bold())
                                .padding(.horizontal, 20)
                            Spacer()
                            Button("Clear All") {
                                clearAllFlaggedData()
                            }
                            .font(.subheadline)
                            .foregroundColor(.accentRosePink)
                            .padding(.horizontal, 20)
                        }

                        if flaggedWords.isEmpty {
                            VStack(spacing: 12) {
                                Image(systemName: "hand.raised.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 60, height: 60)
                                    .foregroundColor(.gray.opacity(0.5))
                                Text("No flagged activity yet.")
                                    .font(.headline)
                                    .foregroundColor(.secondary)
                                Text("Start typing with the SafeThink keyboard to see activity here.")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 40)
                            .background(RoundedRectangle(cornerRadius: 16).fill(Color.lightGrayBackground))
                            .padding(.horizontal, 20)
                            .padding(.top, 20)
                        } else {
                            VStack(spacing: 12) {
                                ForEach(flaggedWords.sorted(by: { $0.timestamp > $1.timestamp })) { word in
                                    FlaggedWordRow(word: word) {
                                        deleteFlaggedWord(word)
                                    }
                                    .padding(.horizontal, 20)
                                    .id(word.id)
                                }
                            }
                        }
                    }
                    .padding(.vertical)
                }
                .navigationTitle("Dashboard")
                .navigationBarTitleDisplayMode(.inline)
            }
        }
        .onAppear(perform: setupListeners)
        .onDisappear(perform: removeListeners)
        .onChange(of: authManager.currentUser?.uid) { newUID in
            if let uid = newUID, authManager.isCurrentUserParent {
                startListeningForFlaggedTexts(parentUID: uid)
            } else {
                stopListening()
            }
            loadFlaggedData()
        }
        .onChange(of: authManager.childrenProfiles) { _ in
            loadFlaggedData()
        }
    }

    private func setupListeners() {
        print("DashboardView: Setting up listeners.")
        NotificationCenter.default.addObserver(forName: NSNotification.Name("FlaggedTextUpdated"), object: nil, queue: .main) { _ in
            print("DashboardView: FlaggedTextUpdated notification received. Reloading data.")
            loadFlaggedData()
        }
        NotificationCenter.default.addObserver(forName: NSNotification.Name("BackgroundFlaggedTextUpdate"), object: nil, queue: .main) { _ in
            print("DashboardView: 'BackgroundFlaggedTextUpdate' notification received. Reloading data.")
            loadFlaggedData()
        }
        loadFlaggedData()

        if let uid = authManager.currentUser?.uid, authManager.isCurrentUserParent {
            startListeningForFlaggedTexts(parentUID: uid)
        }
    }

    private func removeListeners() {
        print("DashboardView: Removing listeners.")
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("FlaggedTextUpdated"), object: nil)
        NotificationCenter.default.removeObserver(self, name: NSNotification.Name("BackgroundFlaggedTextUpdate"), object: nil)
        stopListening()
    }

    private func startListeningForFlaggedTexts(parentUID: String) {
        stopListening()
        print("DEBUG: Starting Firestore listener for parentUID: \(parentUID)")
        let db = Firestore.firestore()
        listener = db.collection("flaggedTexts")
            .whereField("parentUID", isEqualTo: parentUID)
            .addSnapshotListener { snapshot, error in
                if let error = error {
                    print("Error listening: \(error.localizedDescription)")
                    return
                }

                guard let documents = snapshot?.documents else { return }

                var firestoreFlaggedWords: [FlaggedWord] = []
                for document in documents {
                    do {
                        let word = try document.data(as: FlaggedWord.self)
                        firestoreFlaggedWords.append(word)
                    } catch {
                        print("Error decoding FlaggedWord from Firestore: \(error.localizedDescription)")
                        var data = document.data()
                        if let timestamp = data["timestamp"] as? Timestamp {
                            data["timestamp"] = timestamp.dateValue()
                        }
                        if let word = FlaggedWord(dictionary: data) {
                            firestoreFlaggedWords.append(word)
                        }
                    }
                }

                DispatchQueue.main.async {
                    self.flaggedWords = firestoreFlaggedWords.sorted(by: { $0.timestamp > $1.timestamp })
                    self.updateStats()
                    print("DEBUG: Flagged words updated from Firestore listener.")
                }
            }
    }

    private func stopListening() {
        listener?.remove()
        listener = nil
        print("DEBUG: Stopped Firestore listener.")
    }

    func loadFlaggedData() {
        guard let defaults = UserDefaults(suiteName: appGroupId) else {
            print("ERROR: UserDefaults suite is nil in loadFlaggedData.")
            return
        }

        let savedDictionaries = defaults.array(forKey: "FlaggedTexts") as? [[String: Any]] ?? []
        print("DEBUG: Loaded \(savedDictionaries.count) raw dictionaries from UserDefaults.")

        let localFlaggedWords: [FlaggedWord] = savedDictionaries.compactMap { FlaggedWord(dictionary: $0) }

        var relevantUIDs: [String] = []
        if let currentUserID = authManager.currentUser?.uid {
            relevantUIDs.append(currentUserID)
            if authManager.isCurrentUserParent {
                let childUIDs = authManager.childrenProfiles.map { $0.id }
                relevantUIDs.append(contentsOf: childUIDs)
                print("DEBUG: Current user is parent. Relevant UIDs for filtering: \(relevantUIDs)")
            }
        } else {
            print("DEBUG: No current user ID, cannot load flagged words.")
            DispatchQueue.main.async {
                self.flaggedWords = []
                self.stats = []
            }
            return
        }

        let filteredLocalWords = localFlaggedWords.filter { relevantUIDs.contains($0.generatedByUID) }
        print("DEBUG: Loaded \(filteredLocalWords.count) local flagged words for relevant UIDs.")

        if authManager.isCurrentUserParent, let parentUID = authManager.currentUser?.uid {
            print("DEBUG: Parent user. Relying on Firestore listener for data.")
        } else {
            DispatchQueue.main.async {
                self.flaggedWords = filteredLocalWords.sorted(by: { $0.timestamp > $1.timestamp })
                self.updateStats()
            }
        }
    }

    func clearAllFlaggedData() {
        guard let currentUserID = authManager.currentUser?.uid else { return }

        let db = Firestore.firestore()
        let batch = db.batch()

        let collectionRef = db.collection("flaggedTexts")
        let query: Query
        if authManager.isCurrentUserParent {
            query = collectionRef.whereField("parentUID", isEqualTo: currentUserID)
        } else {
            query = collectionRef.whereField("generatedByUID", isEqualTo: currentUserID)
        }

        query.getDocuments { (querySnapshot, error) in
            if let error = error {
                print("Error fetching documents to clear: \(error.localizedDescription)")
                return
            }

            guard let documents = querySnapshot?.documents else { return }

            if documents.isEmpty {
                print("DEBUG: No documents to clear from Firestore.")
                return
            }

            documents.forEach { batch.deleteDocument($0.reference) }

            batch.commit { err in
                if let err = err {
                    print("ERROR: Error deleting batched documents: \(err.localizedDescription)")
                } else {
                    print("DEBUG: Successfully committed deletion batch to Firestore. Listener will update UI.")
                    if !self.authManager.isCurrentUserParent {
                         DispatchQueue.main.async {
                            self.flaggedWords.removeAll()
                            self.updateStats()
                         }
                    }
                }
            }
        }

        guard let defaults = UserDefaults(suiteName: appGroupId) else { return }
        var allSavedDictionaries = defaults.array(forKey: "FlaggedTexts") as? [[String: Any]] ?? []
        allSavedDictionaries.removeAll { dict in
            if let generatedBy = dict["generatedByUID"] as? String {
                if authManager.isCurrentUserParent {
                    let childUIDs = authManager.childrenProfiles.map { $0.id }
                    return generatedBy == currentUserID || childUIDs.contains(generatedBy)
                } else {
                    return generatedBy == currentUserID
                }
            }
            return false
        }
        defaults.set(allSavedDictionaries, forKey: "FlaggedTexts")
    }

    func deleteFlaggedWord(_ wordToDelete: FlaggedWord) {
        let db = Firestore.firestore()
        db.collection("flaggedTexts").document(wordToDelete.id.uuidString).delete { error in
            if let error = error {
                print("ERROR: Error deleting document from Firestore: \(error.localizedDescription)")
            } else {
                print("DEBUG: Successfully deleted flagged word from Firestore. Listener will update UI.")
            }
        }

        guard let defaults = UserDefaults(suiteName: appGroupId) else { return }
        var allSavedDictionaries = defaults.array(forKey: "FlaggedTexts") as? [[String: Any]] ?? []
        allSavedDictionaries.removeAll { ($0["id"] as? String) == wordToDelete.id.uuidString }
        defaults.set(allSavedDictionaries, forKey: "FlaggedTexts")

        if !authManager.isCurrentUserParent {
            DispatchQueue.main.async {
                self.flaggedWords.removeAll { $0.id == wordToDelete.id }
                self.updateStats()
            }
        }
    }

    func saveFlaggedData() {
        guard let currentUserID = authManager.currentUser?.uid, !authManager.isCurrentUserParent else {
            print("DEBUG: User is parent or not logged in. Skipping Firestore upload of child data.")
            saveFlaggedWordsLocally(flaggedWords.filter { $0.generatedByUID == authManager.currentUser?.uid })
            return
        }

        guard let defaults = UserDefaults(suiteName: appGroupId) else { return }
        var allSavedDictionaries = defaults.array(forKey: "FlaggedTexts") as? [[String: Any]] ?? []
        allSavedDictionaries.removeAll { ($0["generatedByUID"] as? String) == currentUserID }
        let currentUserDictionaries = flaggedWords.filter { $0.generatedByUID == currentUserID }.map { $0.toDictionary() }
        allSavedDictionaries.append(contentsOf: currentUserDictionaries)
        defaults.set(allSavedDictionaries, forKey: "FlaggedTexts")

        let db = Firestore.firestore()
        db.collection("users").document(currentUserID).getDocument { document, error in
            let parentUID = document?.data()?["parentUID"] as? String ?? ""
            let batch = db.batch()
            var uploadedCount = 0
            var updatedFlaggedWords = self.flaggedWords

            for i in updatedFlaggedWords.indices {
                if updatedFlaggedWords[i].generatedByUID == currentUserID && !updatedFlaggedWords[i].uploadedToFirestore {
                    let word = updatedFlaggedWords[i]
                    let docRef = db.collection("flaggedTexts").document(word.id.uuidString)
                    var data = word.toDictionary()
                    data["parentUID"] = parentUID
                    batch.setData(data, forDocument: docRef)
                    updatedFlaggedWords[i].uploadedToFirestore = true
                    uploadedCount += 1
                }
            }

            if uploadedCount > 0 {
                batch.commit { err in
                    if let err = err {
                        print("ERROR: Error writing batch to Firestore: \(err.localizedDescription)")
                    } else {
                        print("DEBUG: Successfully batched \(uploadedCount) words to Firestore.")
                        DispatchQueue.main.async {
                            self.flaggedWords = updatedFlaggedWords
                            self.saveFlaggedWordsLocally(updatedFlaggedWords)
                        }
                    }
                }
            } else {
                print("DEBUG: No new words to upload to Firestore for current user.")
            }
        }
    }

    private func saveFlaggedWordsLocally(_ words: [FlaggedWord]) {
        guard let defaults = UserDefaults(suiteName: appGroupId), let currentUserID = authManager.currentUser?.uid else { return }
        var allSavedDictionaries = defaults.array(forKey: "FlaggedTexts") as? [[String: Any]] ?? []
        allSavedDictionaries.removeAll { ($0["generatedByUID"] as? String) == currentUserID }
        let currentUserDictionaries = words.filter { $0.generatedByUID == currentUserID }.map { $0.toDictionary() }
        allSavedDictionaries.append(contentsOf: currentUserDictionaries)
        defaults.set(allSavedDictionaries, forKey: "FlaggedTexts")
        print("DEBUG: Saved updated FlaggedWords (with upload status) to UserDefaults.")
    }

    func updateStats() {
        let calendar = Calendar.current
        let groupedByDay = Dictionary(grouping: flaggedWords) { calendar.startOfDay(for: $0.timestamp) }
        let today = calendar.startOfDay(for: Date())
        var dailyStats: [ToxicStat] = []
        for i in 0..<7 {
            if let date = calendar.date(byAdding: .day, value: -i, to: today) {
                dailyStats.append(ToxicStat(date: date, count: groupedByDay[date]?.count ?? 0))
            }
        }
        stats = dailyStats.sorted { $0.date < $1.date }
        print("DEBUG: Stats updated for chart.")
    }
}

struct FlaggedWordRow: View {
    let word: FlaggedWord
    let onDelete: () -> Void

    var body: some View {
        HStack(spacing: 16) {
            Circle()
                .fill(Color.accentRosePink.opacity(0.2))
                .frame(width: 44, height: 44)
                .overlay(
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.accentRosePink)
                )

            VStack(alignment: .leading, spacing: 4) {
                Text("Flagged Phrase")
                    .font(.subheadline)
                    .fontWeight(.medium)
                    .foregroundColor(.black.opacity(0.7))
                Text(word.text)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .lineLimit(1)
                    .truncationMode(.tail)

                Text(word.timestamp, format: .dateTime.hour().minute().month().day().year())
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }

            Spacer()

            Button(action: onDelete) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
                    .padding(8)
                    .background(Circle().fill(Color.red.opacity(0.1)))
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
    }
}
extension Color {
    static let lightGrayBackground = Color(.systemGray6)
}

struct SettingsView: View {
    @EnvironmentObject var authManager: AuthManager
    @State private var isSyncing = false

    private let appGroupId = "group.com.safethink.app"

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 30) {
                    profileCard
                    connectionCard
                    settingsCard
                    signOutButton
                }
                .padding(.horizontal, 28)
                .padding(.vertical, 24)
            }
            .background(Color.white.ignoresSafeArea())
            .navigationBarTitleDisplayMode(.inline)
            .navigationTitle("Settings")
            .toolbar {
                if !authManager.isCurrentUserParent {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        if isSyncing {
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle())
                        } else {
                            Button(action: {
                                forceSyncData()
                            }) {
                                Image(systemName: "arrow.triangle.2.circlepath")
                                    .font(.title3)
                                    .foregroundColor(.accentRosePink)
                            }
                            .disabled(isSyncing)
                        }
                    }
                }
            }
        }
    }

    private var profileCard: some View {
        VStack(spacing: 16) {
            Image(systemName: "person.crop.circle")
                .resizable()
                .scaledToFit()
                .frame(width: 96, height: 96)
                .foregroundColor(.black.opacity(0.3))
                .padding(.bottom, 4)

            Text(authManager.currentUser?.email ?? "Profile")
                .font(.title3.weight(.semibold))
                .foregroundColor(.black.opacity(0.9))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 24)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: 8)
        )
    }

    private var connectionCard: some View {
        VStack(alignment: .leading, spacing: 24) {
            Text("Your Connection")
                .font(.headline)
                .foregroundColor(.black.opacity(0.6))

            if authManager.isCurrentUserParent {
                if authManager.childrenProfiles.isEmpty {
                    Text("No children paired yet.")
                        .foregroundColor(.black.opacity(0.35))
                        .font(.body)
                } else {
                    ForEach(authManager.childrenProfiles) { child in
                        connectionRow(icon: "person.crop.circle.fill", text: child.email)
                    }
                }
            } else {
                if let parentEmail = authManager.pairedUserEmail {
                    connectionRow(icon: "person.2.fill", text: parentEmail)
                } else {
                    Text("You are not currently paired.")
                        .foregroundColor(.black.opacity(0.35))
                        .font(.body)
                }
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(28)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: 8)
        )
    }

    private func connectionRow(icon: String, text: String) -> some View {
        HStack(spacing: 20) {
            Image(systemName: icon)
                .resizable()
                .scaledToFit()
                .frame(width: 30, height: 30)
                .foregroundColor(.accentRosePink.opacity(0.6))

            Text(text)
                .foregroundColor(.black.opacity(0.9))
                .font(.body)
                .lineLimit(1)
                .layoutPriority(1)

            Spacer()
        }
    }

    private var settingsCard: some View {
        VStack(alignment: .leading, spacing: 24) {
            Text("General Settings")
                .font(.headline)
                .foregroundColor(.black.opacity(0.6))

            settingsRow(icon: "lock.fill", text: "Privacy", url: "https://docs.google.com/document/d/1f5fLwSGqB8yH91MJd4HsUF1rw2TH8zO0pF6iSrbPnhM/edit?usp=sharing")
            settingsRow(icon: "questionmark.circle.fill", text: "Help Center", url: "https://docs.google.com/document/d/1Wg1hzSN7aQm0oOCfEfXA3lT83a3SSb5pUZv4s8C_g50/edit?usp=sharing")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(28)
        .background(
            RoundedRectangle(cornerRadius: 24)
                .fill(Color.white)
                .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: 8)
        )
    }

    private func settingsRow(icon: String, text: String, url: String) -> some View {
        Link(destination: URL(string: url)!) {
            HStack {
                Image(systemName: icon)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 24, height: 24)
                    .foregroundColor(.accentRosePink.opacity(0.7))

                Text(text)
                    .foregroundColor(.black.opacity(0.9))
                    .font(.body)
                    .lineLimit(1)
                    .layoutPriority(1)

                Spacer()

                Image(systemName: "chevron.right")
                    .foregroundColor(Color.black.opacity(0.3))
            }
            .padding(.vertical, 12)
        }
    }

    private var signOutButton: some View {
        Button {
            authManager.signOut()
            print("DEBUG: User signed out.")
        } label: {
            Text("Sign Out")
                .font(.body.weight(.semibold))
                .foregroundColor(.black.opacity(0.75))
                .frame(maxWidth: .infinity)
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color.black.opacity(0.15), lineWidth: 1)
                )
        }
        .padding(.top, 28)
        .buttonStyle(PlainButtonStyle())
    }

    private func forceSyncData() {
        guard let currentUserID = authManager.currentUser?.uid, !authManager.isCurrentUserParent else {
            print("DEBUG: Sync button pressed, but user is a parent. No action taken.")
            return
        }

        self.isSyncing = true
        print("DEBUG: Child user initiated manual data sync.")

        guard let defaults = UserDefaults(suiteName: appGroupId) else {
            print("ERROR: UserDefaults suite is nil in forceSyncData.")
            DispatchQueue.main.async { self.isSyncing = false }
            return
        }

        let savedDictionaries = defaults.array(forKey: "FlaggedTexts") as? [[String: Any]] ?? []
        let localFlaggedWords: [FlaggedWord] = savedDictionaries.compactMap { FlaggedWord(dictionary: $0) }
        let wordsToUpload = localFlaggedWords.filter { $0.generatedByUID == currentUserID && !$0.uploadedToFirestore }

        if wordsToUpload.isEmpty {
            print("DEBUG: No new words to upload during manual sync.")
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.isSyncing = false
            }
            return
        }

        let db = Firestore.firestore()
        db.collection("users").document(currentUserID).getDocument { document, error in
            if let error = error {
                print("ERROR: Could not get user document to find parentUID: \(error.localizedDescription)")
                DispatchQueue.main.async { self.isSyncing = false }
                return
            }

            let parentUID = document?.data()?["parentUID"] as? String ?? ""
            if parentUID.isEmpty {
                print("DEBUG: Child is not paired with a parent. Cannot sync.")
                DispatchQueue.main.async { self.isSyncing = false }
                return
            }

            let batch = db.batch()
            for var word in wordsToUpload {
                let docRef = db.collection("flaggedTexts").document(word.id.uuidString)
                word.parentUID = parentUID
                word.uploadedToFirestore = true
                batch.setData(word.toDictionary(), forDocument: docRef)
            }

            batch.commit { err in
                if let err = err {
                    print("ERROR: Error writing batch to Firestore during manual sync: \(err.localizedDescription)")
                    DispatchQueue.main.async { self.isSyncing = false }
                } else {
                    print("DEBUG: Successfully batched \(wordsToUpload.count) words to Firestore during manual sync.")
                    var allSavedDictionaries = savedDictionaries
                    for i in allSavedDictionaries.indices {
                        if let idString = allSavedDictionaries[i]["id"] as? String,
                           wordsToUpload.contains(where: { $0.id.uuidString == idString }) {
                            allSavedDictionaries[i]["uploaded"] = true
                        }
                    }
                    defaults.set(allSavedDictionaries, forKey: "FlaggedTexts")
                    print("DEBUG: Updated UserDefaults to mark words as uploaded.")
                    DispatchQueue.main.async { self.isSyncing = false }
                }
            }
        }
    }
}
