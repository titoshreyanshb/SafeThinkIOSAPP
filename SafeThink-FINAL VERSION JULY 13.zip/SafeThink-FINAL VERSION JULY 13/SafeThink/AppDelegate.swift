

import UIKit
import FirebaseCore
import GoogleSignIn
import SwiftUI
import Firebase
import FirebaseAuth
import FirebaseFirestore

class AppDelegate: UIResponder, UIApplicationDelegate {

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

        FirebaseApp.configure()
        application.setMinimumBackgroundFetchInterval(UIApplication.backgroundFetchIntervalMinimum)

        print("✅ Firebase configured. Background fetch enabled.")
        return true
    }

    func application(_ application: UIApplication,
                     performFetchWithCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {

        print("🌙 Background fetch triggered...")

        let appGroupId = "group.com.safethink.app"
        guard let defaults = UserDefaults(suiteName: appGroupId) else {
            print("❌ Failed to access UserDefaults for app group.")
            completionHandler(.failed)
            return
        }

        let savedDictionaries = defaults.array(forKey: "FlaggedTexts") as? [[String: Any]] ?? []
        var localFlaggedWords: [FlaggedWord] = savedDictionaries.compactMap { FlaggedWord(dictionary: $0) }

        guard let currentUserUID = defaults.string(forKey: "currentUserUID"), !currentUserUID.isEmpty else {
            print("❌ No currentUserUID found in UserDefaults.")
            completionHandler(.noData)
            return
        }

        let db = Firestore.firestore()

        db.collection("users").document(currentUserUID).getDocument { docSnapshot, error in
            guard error == nil, let parentUID = docSnapshot?.data()?["parentUID"] as? String else {
                print("❌ Error fetching parentUID or document not found.")
                completionHandler(.failed)
                return
            }

            let batch = db.batch()
            var uploadedCount = 0

            for i in 0..<localFlaggedWords.count {
                if !localFlaggedWords[i].uploadedToFirestore {
                    let word = localFlaggedWords[i]
                    let docRef = db.collection("flaggedTexts").document(word.id.uuidString)
                    let data: [String: Any] = [
                        "id": word.id.uuidString,
                        "text": word.text,
                        "timestamp": Timestamp(date: word.timestamp),
                        "generatedByUID": word.generatedByUID,
                        "parentUID": parentUID
                    ]
                    batch.setData(data, forDocument: docRef)
                    localFlaggedWords[i].uploadedToFirestore = true
                    uploadedCount += 1
                }
            }

            if uploadedCount > 0 {
                batch.commit { err in
                    if let err = err {
                        print("❌ Error writing batch: \(err.localizedDescription)")
                        completionHandler(.failed)
                    } else {
                        print("✅ Background upload of \(uploadedCount) flagged texts complete.")
                        let updated = localFlaggedWords.map { $0.toDictionary() }
                        defaults.set(updated, forKey: "FlaggedTexts")
                        completionHandler(.newData)
                    }
                }
            } else {
                print("ℹ️ No new data to upload.")
                completionHandler(.noData)
            }
        }
    }

    func application(_ app: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        return GIDSignIn.sharedInstance.handle(url)
    }
}

