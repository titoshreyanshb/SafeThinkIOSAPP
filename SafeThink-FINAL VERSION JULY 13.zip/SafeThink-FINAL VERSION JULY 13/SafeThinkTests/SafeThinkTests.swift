

import Testing
@testable import SafeThink

struct SafeThinkTests {

    @Test func example() async throws {
       
    }

}
